(function (DR, document) {
    "use strict";

    if (RegExp('/r/danganronpa/', 'i').test(location.href) && !RegExp("class trial", "i").test(document.title))
        return;

    function RoleHandler() {
        this.users = [];
        this.characters = {};
        this.timezones = {};
    }

    Object.defineProperties(RoleHandler.prototype, {
        'length': {
            get: function () {
                return Object.keys(this.characters).length;
            }
        },
        'get': {
            writable: false,
            value: function (user) {
                if (typeof user == 'string')
                    return this.characters[user.toLowerCase()];
                else
                    return this.users[user];
            }
        },
        'set': {
            writable: false,
            value: function (user, role) {
                if (this.exists(user) || this.exists(role))
                    console.warn('Duplicated role:', user, DR.NAMES[role]);

                this.users[role] = user;
                this.characters[user.toLowerCase()] = role;
            }
        },
        'setExternal': {
            writable: false,
            value: function (username, url) {
                // Load the JSON
                return DR.fetch('GET', url)
                    .then(function (data) {
                        // Get a new Role Slot
                        var role = DR.ROLES.assign(data.name);
                        // and assign it to the new guy
                        this.set(username, role.code);
                        // along with their resources
                        DR.NAMES[role.code] = data.name;
                        DR.FLAIRS[role.code] = 'flair-external' + role.key.toLowerCase();
                        DR.SPRITES[role.code] = data.sprites;

                        // Now for their flair
                        return new Promise(function (resolve, reject) {
                            // download it
                            var flair = new Image();
                            flair.src = data.flair;
                            flair.onload = resolve;
                            flair.onerror = reject;
                        }).then(function (evt) {
                            DR.FLAIRS[role.code] = 'flair-' + role.key.toLowerCase();

                            var style = document.createElement('style');
                            // get the flair size and prepare to...
                            style.textContent = '.flair.flair-' + role.key.toLowerCase() + '{background-image:url(' + evt.target.src + ');background-position:center;width:' + evt.target.naturalWidth + 'px;height:' + evt.target.naturalHeight + 'px}';
                            // ...put it in the sub
                            document.querySelector('head').appendChild(style);
                        });
                    }.bind(this))
                    .then(null, function (err) {
                        console.warn('An external character failed to load:', username, err);
                    });
            }
        },
        'exists': {
            writable: false,
            value: function (user) {
                if (typeof user == 'string')
                    return (user.toLowerCase() in this.characters);
                else
                    return (user in this.users);
            }
        },
        'getTz': {
            writable: false,
            value: function (user) {
                return this.timezones[user] || 0;
            }
        },
        'setTz': {
            writable: false,
            value: function (user, offset) {
                this.timezones[user] = offset;
            }
        },
        'hasTz': {
            writable: false,
            value: function (user) {
                return (user in this.timezones);
            }
        },
        'getUTCLabel': {
            writable: false,
            value: function (user) {
                var offset = this.getTz(user),
                    output = 'UTC';

                if (offset !== 0) {
                    output += offset > 0 ? '+' : '';
                    output += Math[offset < 0 ? 'ceil' : 'floor'](offset);

                    if (offset % 1 !== 0)
                        output += ':' + (Math.abs(offset % 1) * 60).toString().slice(0, 2);
                }

                return output;
            }
        },
        'getLocalTime': {
            writable: false,
            value: function (user) {
                var here = new Date();
                return new Date(here.getTime() + (here.getTimezoneOffset() + this.getTz(user) * 60) * 60 * 1000);
            }
        },
        'timeLeftToAppear': {
            writable: false,
            value: function (y) {
                var list = {},
                    requests = this.users.map(itm => {
                        if (!itm)
                            return;

                        return fetch('https://www.reddit.com/user/' + itm + '.json')
                            .then(res => res.json())
                            .then(info => {
                                var data = info.data.children.filter(rep => rep.data.subreddit_id == "t5_3ckk4")[0].data;
                                var limit = Math.max(y, data.created_utc) + 86400,
                                    delta = limit - (Date.now() / 1000);
                                list[data.author] = Math.floor(delta / 3600) + ' hours, ' + Math.floor((delta % 3600) / 60) + ' minutes';
                            });
                    });

                Promise.all(requests).then(i => { console.log('Done!', list); })
            }
        }
    });

    function parseTimezone(line) {
        var offset;

        line = line.replace(/\s/g, '');
        offset = RegExp('[\\[\\(](UTC|GMT)([\\+\\-]\\d{1,2})\\:?(\\d\\d)?[\\]\\)]', 'i').exec(line);

        if (offset && offset[2]) {
            line = parseInt(offset[2]);

            if (offset[3]) {
                line += (line < 0 ? -1 : 1) * parseInt(offset[3]) / 60;
            }

            return line;
        }

        else if (offset && offset[1])
            return 0;
    }

    function identifyCharacter(line) {
        line = ' ' + line + ' ';

        if (RegExp('\\syui\\W|\\ssamidare\\W', 'i').test(line))
            return DR.ROLES.YUI;

        if (RegExp('\\syasuke\\W|\\smatsuda\\W', 'i').test(line))
            return DR.ROLES.YASUKE;

        if (RegExp('\\ssanta\\W|\\sshikiba\\W', 'i').test(line))
            return DR.ROLES.SANTA;

        if (RegExp('\\smasaru\\W|\\sdaimon\\W', 'i').test(line))
            return DR.ROLES.MASARU;

        if (RegExp('\\sjataro\\W|\\skemuri\\W', 'i').test(line))
            return DR.ROLES.JATAROU;

        if (RegExp('\\skotoko\\W|\\sutsugi\\W', 'i').test(line))
            return DR.ROLES.KOTOKO;

        if (RegExp('\\snagisa\\W|\\sshingetsu\\W', 'i').test(line))
            return DR.ROLES.NAGISA;

        if (RegExp('\\smona[ck]a\\W', 'i').test(line))
            return DR.ROLES.MONACA;

        if (RegExp('\\shaiji\\W|\\stowa\\W', 'i').test(line))
            return DR.ROLES.HAIJI;

        if (RegExp('\\staichi.+fujisaki\\W', 'i').test(line))
            return DR.ROLES.TAICHI;

        if (RegExp('\\syuu?ta.+asahina\\W', 'i').test(line))
            return DR.ROLES.YUUTA;

        if (RegExp('\\smonokuma\\W', 'i').test(line))
            return DR.ROLES.MONOKUMA;

        if (RegExp('\\smonomi\\W|\\susami\\W', 'i').test(line))
            return DR.ROLES.MONOMI;

        if (RegExp('\\smecha[\\-\\s]?maru\\W', 'i').test(line))
            return DR.ROLES.MECHAMARU;

        if (RegExp('\\snidai\\W|\\snekomaru\\W', 'i').test(line))
            return DR.ROLES.NEKOMARU;

        if (RegExp('\\simpost[eo]r\\W|\\stwogami\\W', 'i').test(line))
            return DR.ROLES.IMPOSTER;

        if (RegExp('\\sikusaba\\W|\\smukuro\\W', 'i').test(line))
            return DR.ROLES.MUKURO;

        if (RegExp('\\saoi\\W|\\sasahina\\W', 'i').test(line))
            return DR.ROLES.AOI;

        if (RegExp('\\sbyakuya\\W|\\stogami\\W', 'i').test(line))
            return DR.ROLES.BYAKUYA;

        if (RegExp('\\sceles(?:te|tia)?\\W|\\sludenb[eu]rg\\W', 'i').test(line))
            return DR.ROLES.CELES;

        if (RegExp('\\sfujisaki\\W|\\schihiro\\W', 'i').test(line))
            return DR.ROLES.CHIHIRO;

        if (RegExp('\\shagakure\\W|\\syasuhiro\\W', 'i').test(line))
            return DR.ROLES.YASUHIRO;

        if (RegExp('\\shifumi\\W|\\syamada\\W', 'i').test(line))
            return DR.ROLES.HIFUMI;

        if (RegExp('\\sishimaru\\W|\\skiyotaka\\W', 'i').test(line))
            return DR.ROLES.KIYOTAKA;

        if (RegExp('\\sjunko\\W|\\senoshima\\W', 'i').test(line))
            return DR.ROLES.JUNKO;

        if (RegExp('\\skyou?ko\\W|\\skirigiri\\W', 'i').test(line))
            return DR.ROLES.KYOUKO;

        if (RegExp('\\sleon\\W|\\skuwata\\W', 'i').test(line))
            return DR.ROLES.LEON;

        if (RegExp('\\smaizono\\W|\\ssayaka\\W', 'i').test(line))
            return DR.ROLES.SAYAKA;

        if (RegExp('\\smondo\\W|\\so[oh]?wada\\W', 'i').test(line))
            return DR.ROLES.MONDO;

        if (RegExp('\\skomaru\\W|komaru\\snaegi', 'i').test(line))
            return DR.ROLES.KOMARU;

        if (RegExp('\\smakoto\\W|makoto\\snaegi', 'i').test(line))
            return DR.ROLES.MAKOTO;

        if (RegExp('\\ssakura\\W|\\so[oh]?gami\\W', 'i').test(line))
            return DR.ROLES.SAKURA;

        if (RegExp('\\stou?ko\\W|\\sfukawa\\W|\\sgenocider\\W', 'i').test(line))
            return DR.ROLES.TOUKO;

        if (RegExp('\\sakane\\W|\\sowari\\W', 'i').test(line))
            return DR.ROLES.AKANE;

        if (RegExp('\\sgundh?am\\W|\\stanaka\\W', 'i').test(line))
            return DR.ROLES.GUNDHAM;

        if (RegExp('\\shanamura\\W|\\steruteru\\W', 'i').test(line))
            return DR.ROLES.TERUTERU;

        if (RegExp('\\shinata\\W|\\shajime\\W', 'i').test(line))
            return DR.ROLES.HAJIME;

        if (RegExp('\\skoizumi\\W|\\smahiru\\W', 'i').test(line))
            return DR.ROLES.MAHIRU;

        if (RegExp('\\skuzuryu\\W|\\sfuyuhiko\\W', 'i').test(line))
            return DR.ROLES.FUYUHIKO;

        if (RegExp('\\snagito\\W|\\skomaeda\\W', 'i').test(line))
            return DR.ROLES.NAGITO;

        if (RegExp('\\snanami\\W|\\schiaki\\W', 'i').test(line))
            return DR.ROLES.CHIAKI;

        if (RegExp('\\spekoyama\\W|\\speko\\W', 'i').test(line))
            return DR.ROLES.PEKO;

        if (RegExp('\\ssaionji\\W|\\shiyoko\\W', 'i').test(line))
            return DR.ROLES.HIYOKO;

        if (RegExp('\\ssonia\\W|\\snevermind\\W', 'i').test(line))
            return DR.ROLES.SONIA;

        if (RegExp('\\ssou?da\\W|\\skazuichi\\W', 'i').test(line))
            return DR.ROLES.KAZUICHI;

        if (RegExp('\\stsumiki\\W|\\smikan\\W', 'i').test(line))
            return DR.ROLES.MIKAN;

        if (RegExp('\\sibuki\\W|\\smioda\\W', 'i').test(line))
            return DR.ROLES.IBUKI;

        if (RegExp('\\salter\\s?ego\\W', 'i').test(line))
            return DR.ROLES.ALTEREGO;
    }

    function processRoleList(text) {
        var promises = [],
            roles = new RoleHandler(),
            // The regex matches a whole line if it contains a reddit username [u/user-name_0]
            regex = /^(.*)u\/([A-Za-z0-9-_]+)(.*)$/igm;

        var result,
            promise,
            line, username,
            character, offset,
            url, url_start, url_end;

        while (result = regex.exec(text)) {
            line = result[0];
            username = result[2];

            // Find an external role assignment
            url_start = line.indexOf('http');
            url_end = line.indexOf('.json');

            if (url_start > -1 && url_end > -1 && url_start < url_end) {
                url = line.slice(url_start, url_end + 5);

                promise = roles.setExternal(username, url);
                promises.push(promise);

            } else {
                character = identifyCharacter(result[3]) || identifyCharacter(result[1]);

                if (character > 0) {
                    roles.set(result[2], character);

                    offset = parseTimezone(result[0]);
                    if (offset != null)
                        roles.setTz(result[2], offset);
                }
            }
        }

        return Promise.all(promises)
            .then(function () {
                return roles;
            });
    }

    DR.fetch('GET', './this.json').then(function (media) {
        var info = media[0].data.children[0].data;

        processRoleList(info.selftext)
            .then(function (roles) {
                if (!(/summary/i).test(document.title)
                    && roles.length > 10
                    && !roles.exists(DR.ROLES.MONOKUMA)
                    && !roles.exists(info.author)
                ) {
                    roles.set(info.author, DR.ROLES.MONOKUMA);
                }

                console.debug('Identified roles:', roles);

                DR.roleList = roles;
                DR.triggerEvent('rolesidentified', roles);

                roles.timeLeftToAppear(info.created_utc);
            });
    });

    DR.identifyCharacter = identifyCharacter;
})(window.DRreddit, document);